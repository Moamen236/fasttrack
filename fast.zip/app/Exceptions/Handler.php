<?php

namespace App\Exceptions;

use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Throwable;

class Handler extends ExceptionHandler
{
    /**
     * A list of the exception types that are not reported.
     *
     * @var array
     */
    protected $dontReport = [
        //
    ];

    /**
     * A list of the inputs that are never flashed for validation exceptions.
     *
     * @var array
     */
    protected $dontFlash = [
        'password',
        'password_confirmation',
    ];


    public function report(Throwable $exception)
    {
        parent::report($exception);
    }


    public function render($request, Throwable $exception){
        
        if(request()->is('api/*')){
            $message =  $exception->getMessage();
            return response()->json($message,500);    
        }
        
        if ($this->isHttpException($exception)) {
           
            
            if ($exception->getStatusCode() == 404) {
                
                return response()->view('frontend.pages.404');
            }
            if ($exception->getStatusCode() == 500 && !request()->is('api/v1/*')) {
                return response()->view('frontend.pages.500');
            }
           
        }
        
        return parent::render($request, $exception);
    }


}
